\<?php

$EMAIL_ID = 123456789; // 9-digit integer value (i.e., 123456789)

require_once '/home/common/php/dbInterface.php'; // Add database functionality
require_once '/home/common/php/mail.php'; // Add email functionality
require_once '/home/common/php/p4Functions.php'; // Add Project 4 base functions

processPageRequest(); // Call the processPageRequest() function

// DO NOT REMOVE OR MODIFY THE CODE OR PLACE YOUR CODE ABOVE THIS LINE

function authenticateUser($username, $password) 
{
	$userLogin=array;
	$userLogin=validateUser($username, $password);
	if($userLogin != null){
		session_start();
		$_SESSION["userId"]
		$_SESSION["displayName"]
		$_SESSION["emailAddress"]
		return true;
	}
	else{
		return false;
	}
}

function displayLoginForm($message = "")
{
	require_once './templates/logon_form.html'; //should connect to the login page
}

function processPageRequest()
{
	// DO NOT REMOVE OR MODIFY THE CODE OR PLACE YOUR CODE BELOW THIS LINE
	if(session_status() == PHP_SESSION_ACTIVE)
	{
		session_destroy();
	}
	// DO NOT REMOVE OR MODIFY THE CODE OR PLACE YOUR CODE ABOVE THIS LINE
	if(empty($_POST))
	{
		displayLoginForm();
	}
	if($_POST['action'] == 'login'){
		header("Location: ../project4/index.php");
	}
}

?>
