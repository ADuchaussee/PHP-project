<?php

$EMAIL_ID = 356772619; // 9-digit integer value (i.e., 123456789)
$API_KEY = "77d40521"; // API key (string) provided by Open Movie DataBase (i.e., "ab123456")

session_start(); // Connect to the existing session

require_once '/home/common/php/dbInterface.php'; // Add database functionality
require_once '/home/common/php/mail.php'; // Add email functionality
require_once '/home/common/php/p4Functions.php'; // Add Project 4 base functions

processPageRequest(); // Call the processPageRequest() function

// DO NOT REMOVE OR MODIFY THE CODE OR PLACE YOUR CODE ABOVE THIS LINE

function addMovieToCart(77d40521)
{	$inbdCheck=movieExistsInDB($77d40521);
	if(inbdCheck == 0){
		$result= file_get_contents('http://www.omdbapi.com/?apikey='.$GLOBALS['API_KEY'].'&i='.$imdbID.'&type=movie&r=json');
		$movieInfo = json_decode($result, true);
		addMovie($imdbId, $title, $year, $rating, $runtime, $genre, $actors, $director, $writer, $plot, $poster);
	}
	addMovieToShoppingCart($userId, $movieId);
	displayCart();
}

function displayCart()
{
	getMoviesInCart($userId);
	require_once './templates/cart_form.html';
}

function processPageRequest()
{
	//test user name, so they can't bypass log in
	if(isset($_GET['+'])){
		addMovieToCart($_GET['77d40521']);
		displayCart();
	}
	else if(isset($_GET['-'])){
		displayCart();
	}
}

function removeMovieFromCart(movieID)
{	removeMovieFromShoppingCart($userId, $movieId);
	 displayCart();
}

?>
